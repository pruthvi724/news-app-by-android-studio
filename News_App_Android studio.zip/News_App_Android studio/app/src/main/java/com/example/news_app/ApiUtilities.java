package com.example.news_app;

import retrofit2.converter.gson.GsonConverterFactory;

public class ApiUtilities {

    private static Retrofit retrofit=null;

    private static class Retrofit {
        public void create(Class<ApiInterface> apiInterfaceClass) {
        }

        public static class Builder {
            public void baseUrl(String baseUrl) {
            }
        }
    }
    retrofit2.Retrofit.Builder
    public static void getApiInterface()
    {

        if(retrofit==null)
        {
            retrofit=new Retrofit.Builder().baseUrl(ApiInterface.BASE_URL).addConverterFactory(GsonConverterFactory.create()
                    .build();
        }
        return retrofit.create(ApiInterface.class);
    }
}
